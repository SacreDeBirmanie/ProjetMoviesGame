package users;

public class UserData{

        private String name;
        private String mel;

        public String getName() {
                return name;
        }

        public void setName(String name) {
                this.name = name;
        }

        public String getmel() {
                return mel;
        }

        public void setMel(String mel) {
                this.mel = mel;
        }

}